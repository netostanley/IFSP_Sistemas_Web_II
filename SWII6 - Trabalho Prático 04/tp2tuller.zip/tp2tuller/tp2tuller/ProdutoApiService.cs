﻿using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using tp2tuller.Models;

public class ProdutoApiService
{
    private readonly HttpClient _httpClient;

    public ProdutoApiService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    // Método para buscar todos os produtos
    public async Task<List<Produto>> GetProdutosAsync()
    {
        var response = await _httpClient.GetAsync("produtos");
        response.EnsureSuccessStatusCode();

        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<List<Produto>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }

    // Método para buscar um produto pelo ID
    public async Task<Produto> GetProdutoByIdAsync(int id)
    {
        var response = await _httpClient.GetAsync($"produtos/{id}");
        response.EnsureSuccessStatusCode();

        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<Produto>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }

    // Método para criar um produto
    public async Task<bool> CreateProdutoAsync(Produto produto)
    {
        var json = JsonSerializer.Serialize(produto);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _httpClient.PostAsync("produtos", content);
        return response.IsSuccessStatusCode;
    }

    // Método para editar um produto
    public async Task<bool> UpdateProdutoAsync(int id, Produto produto)
    {
        var json = JsonSerializer.Serialize(produto);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _httpClient.PutAsync($"produtos/{id}", content);
        return response.IsSuccessStatusCode;
    }

    // Método para deletar um produto
    public async Task<bool> DeleteProdutoAsync(int id)
    {
        var response = await _httpClient.DeleteAsync($"produtos/{id}");
        return response.IsSuccessStatusCode;
    }
}
