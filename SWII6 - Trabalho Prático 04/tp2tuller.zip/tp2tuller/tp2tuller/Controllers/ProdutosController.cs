﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using tp2tuller.Models;

namespace tp2tuller.Controllers
{
    public class ProdutosController : Controller
    {
        private readonly ProdutoApiService _produtoApiService;

        public ProdutosController(ProdutoApiService produtoApiService)
        {
            _produtoApiService = produtoApiService;
        }

        // Index: Lista todos os produtos
        public async Task<IActionResult> Index()
        {
            var produtos = await _produtoApiService.GetProdutosAsync();
            return View(produtos);
        }

        // Details: Exibe os detalhes de um produto
        public async Task<IActionResult> Details(int id)
        {
            var produto = await _produtoApiService.GetProdutoByIdAsync(id);
            if (produto == null)
            {
                return NotFound();
            }
            return View(produto);
        }

        // Create: Formulário para criar um produto
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Produto produto)
        {
            if (ModelState.IsValid)
            {
                var success = await _produtoApiService.CreateProdutoAsync(produto);
                if (success)
                {
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(produto);
        }

        // Edit: Formulário para editar um produto
        public async Task<IActionResult> Edit(int id)
        {
            var produto = await _produtoApiService.GetProdutoByIdAsync(id);
            if (produto == null)
            {
                return NotFound();
            }
            return View(produto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Produto produto)
        {
            if (ModelState.IsValid)
            {
                var success = await _produtoApiService.UpdateProdutoAsync(id, produto);
                if (success)
                {
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(produto);
        }

        // Delete: Exibe o produto para confirmação
        public async Task<IActionResult> Delete(int id)
        {
            var produto = await _produtoApiService.GetProdutoByIdAsync(id);
            if (produto == null)
            {
                return NotFound();
            }
            var success = await _produtoApiService.DeleteProdutoAsync(id);
            if (success)
            {
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var success = await _produtoApiService.DeleteProdutoAsync(id);
            if (success)
            {
                return RedirectToAction(nameof(Index));
            }
            return View();
        }
    }
}
